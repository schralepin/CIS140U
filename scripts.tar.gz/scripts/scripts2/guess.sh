secretname=dona
name=noname
until [ $name = $secretname ]
do
   read -p "guess a name: " name
done 
echo Very Good!
