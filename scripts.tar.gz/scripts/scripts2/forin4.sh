for file in *
do
   if [ -d $file ] 
      then
          echo "This is a directory: $file"
      else
          echo "This is a file: $file"
          echo "=====THIS IS THE WHOLE FILE================"
          cat $file
          echo "++++THIS IS ONLY LINES WITH 'a' IN THEM++++"
          grep 'a' $file
          echo "+-+-+-+-+-+"
   fi
done

