
list=$(seq 6 3 22)
echo $list

list=$(seq 6 9)
echo $list

list=$(seq 4)
echo $list
