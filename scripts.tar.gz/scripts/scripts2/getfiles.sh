# this script will go through all the 
# subdirectories in the current directory
# it will look to see if a passed-in filename
# exists and if it does, print it to the terminal

# go through directory entries

if [ $# -lt 1 ]; then
    echo "need file name as one argument"
    exit -1
fi

filename=$1  # not needed but I like descriptive variable names
for entry in *
do
    #check for whether this is a directory or not
    if [ -d $entry ]; then
       #is a directory
       # check to see if a file name todo.txt exists
       if [ -e "$entry/$filename" ]; then
          # use cat to print file
          cat "$entry/$filename"
       fi
    fi
done
