/*
Course:        CS 140U
Assignment:    Assessment 3 (editors and mail)
*/
#include <iostream>
#include <iomanip>
#include <string>
#include <chrono>
#include <ctime>
#include <cstring>
#include <sys/types.h>
#include <pwd.h>
#include <cstdlib>
#include <unistd.h>
#include <cstdio>

void print_greeting();


