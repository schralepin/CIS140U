# if statement example
# $1 is the first argument

if [ $1 -eq 0 ]
   then
     echo "You typed zero"
fi
echo "End of Program"

