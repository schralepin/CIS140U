
# go through directory entries
for entry in *
do
   #check for whether this is a directory or not
   if [ -d $entry ]; then
      #is a directory
      # check to see if a file name todo.txt exists
      if [ -e "$entry/todo.txt" ]; then
          # use cat to print file
          cat "$entry/todo.txt"
      fi
   fi
done
