# if/elif/else example
#

# check for two arguments 
if [ $# -lt 2 ] 
   then
      echo "Need to provide two numbers"
      exit 1
fi

# printout if 1st argument is greater than
# or less than or equal to the 2nd argument
#   
if [ $1 -gt $2 ]
   then 
      echo "Your first number is greater than your second number."
   elif [ $1 -lt $2 ]
     then
        echo "Your first number is lesser than or equal to the second number."
   else # no need for a conditional. has to be equal
      echo "Your numbers are equal"
fi

