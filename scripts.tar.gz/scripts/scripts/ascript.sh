# this is a simple script

date  #prints the date
echo "This is a script"
echo " This the who command"
who   #prints out information about users on the system
echo " This is the current directory"
ls -al #prints all files and subdirectories in cwd

