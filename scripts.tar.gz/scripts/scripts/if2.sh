# if/else example
#

# check for two arguments
#   $# is number of arguments given
#   -lt  is "less than" 
if [ $# -lt 2 ] 
   then
      echo "Need to provide two numbers"
      exit 1
fi

# printout if 1st argument is greater than or less than 2nd argument
#    -gt is "greater than"
if [ $1 -gt $2 ]
   then 
      echo "Your first number is greater than your second number."
   else
      echo "Your first number is lesser than or equal to the second number."
fi

