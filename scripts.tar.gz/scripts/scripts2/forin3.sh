echo "WITH = "
for animal in $@
do
   echo $animal
done

echo "WITHOUT = "

for animal
do
   echo $animal
done
