if [ $# -lt 2 ]
   then
      echo "Need to provide 2 words"
      exit 1
fi

if [ "$1" = "$2" ]
   then
      echo Match
   else
      echo No Match
fi
echo "end of program" 
