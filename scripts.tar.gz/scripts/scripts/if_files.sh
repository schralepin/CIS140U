#this illustrates the filesystem tests that can be done

if [ $# -eq 0 ] 
  then 
    echo "Need to provide a file name"
    exit 1
fi

if [ -e $1 ]
  then
     echo "The file/dir $1 exists"
  else
     echo "The file/dir $1 doesn't exists"
fi

if [ -f $1 ]
  then
    echo "$1 exists and is a file"
  else
    echo "$1 does not exists or is not a file"
fi

if [ -d $1 ]
   then
      echo "$1 exists and is a directory"
   else
      echo "$1 does not exists or is not a directory"
fi

if [ -r $1 ] 
  then
    echo "$1 exists and is readable"
  else
    echo "$1 either does not exists or is not readable"
fi

if [ -s $1 ] 
  then
    echo "$1 exists and has size greater than 0 (not and empty file)"
  else
    echo "$1 either does not exists or is an empty file "
fi

if [ -w $1 ]
  then
    echo "$1 exists and is a writeable file"
  else
    echo "$1 either does not exists or is not a writeable file"
fi

if [ -x $1 ]
  then 
    echo "$1 exists and is executable file"
  else
    echo "$1 either does not exists or is not an executable file"
fi

#check current working directory
dir=$(pwd)
echo $dir
if [ -w $dir ] 
  then
    echo "can write to current directory"
  else
    echo "cannot write to current director (or something else)"
fi
echo "End of program"


