
for flower in roses azaleas zinnias camellias
do
   echo $flower
done

