
count=0 
while [ $count -lt 5 ] 
    do
          echo "count is $count"
          (( count += 1 ))
    done
