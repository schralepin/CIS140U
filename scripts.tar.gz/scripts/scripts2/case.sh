case $1 in
   a*) echo $1 starts with an 'a'
          ;;
   b*) echo $1 starts with an 'b'
          ;;
   *)  echo 1$ starts with something other than a or b.
          ;;
esac
 
