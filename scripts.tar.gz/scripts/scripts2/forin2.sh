sum=0
for count in $(seq 12 2 1)
do
  echo "adding $count"
  sum=$(($sum + $count))
done
echo "sum is $sum"
